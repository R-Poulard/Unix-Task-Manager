#include "utils.c"
#include "cmd_create.c"
#include "cmd_list.c"
#include "cmd_time_exit_code.c"
#include "cmd_std.c"
#include "cmd_remove.c"
#include "cmd_switch_time.c"
#include "cmd_set_cmd_task.c"
#include "cmd_exec_task.c"
#include "cmd_reset_taskmax.c"
#include "saturnd_child.c"

void handler(int s){
  switch(s){
    case SIGALRM: 
    break;
    case SIGTERM: 
      while(waitpid(-1,NULL,WNOHANG)>0);
      exit(EXIT_SUCCESS);
    break;
  }
}
int main(){
  char * pipes_directory;
  char * username_str = getlogin();
  
  pipes_directory = malloc(PATH_SIZE);//creation of the default PIPES_DIR//MALLOC
  strcpy(pipes_directory, "/tmp/");
  strcat(pipes_directory, username_str);
  mkdir(pipes_directory,0751);//MKDIR
  
  strcat(pipes_directory, "/saturnd");
  mkdir(pipes_directory,0751);//MKDIR
  
  strcat(pipes_directory, "/pipes");
  mkdir(pipes_directory,0751);//MKDIR
  
  char *fifo_request=malloc(PATH_SIZE);//MALLOC
  strcpy(fifo_request,pipes_directory);
  strcat(fifo_request,"/saturnd-request-pipe");
  
  char *fifo_reply = malloc(PATH_SIZE);//MALLOC
  strcpy(fifo_reply,pipes_directory);
  strcat(fifo_reply,"/saturnd-reply-pipe");  
  
  //PATHTASKS
  char * pathtasks_saturnd = malloc(PATH_SIZE);//MALLOC
  strcpy(pathtasks_saturnd,"./saturnd_dir");
  mkdir(pathtasks_saturnd, 0751);//MKDIR
     
  char * pathtasks = malloc(PATH_SIZE);//MALLOC
  strcpy(pathtasks,"./saturnd_dir/tasks/");
    
  mkdir(pathtasks,0751);//MKDIR
  struct stat stat_request;
  struct stat stat_reply;
  
  if(stat(fifo_request,&stat_request)==-1 || S_ISFIFO(stat_request.st_mode)==0){
    mkfifo(fifo_request,0751);//MKFIFO
  }
  if(stat(fifo_reply,&stat_reply)==-1 || S_ISFIFO(stat_reply.st_mode)==0){
    mkfifo(fifo_reply,0751);//MKFIFO
  }
  
  char * buftaskmax;
  buftaskmax = path_constr(buftaskmax,pathtasks_saturnd,"taskid_max");//MALLOC
   
  free(pipes_directory);

  pid_t pid = fork();//FORK
  //if(pid<0)goto;
  
  if(pid>0){//GRAND PERE
    int fd_request=open(fifo_request,O_RDONLY);//OPEN
    int fd_reply=open(fifo_reply,O_WRONLY);//OPEN

    free(fifo_request);
    free(fifo_reply);

    int out=0;
    uint16_t u16;
    uint64_t taskid;

    char * buf;
    int fd_buftask;
    
    int rd;
    time_t time2;
    
    while(out==0){ 
      rd = read(fd_request,&u16,sizeof(uint16_t));
      if(rd>0){  
        u16=htobe16(u16);
    
        switch (u16){                         
          case CLIENT_REQUEST_DELETE_ALL: 
            remove_all(pathtasks,fd_reply,pathtasks_saturnd);
          break;  
          case CLIENT_REQUEST_SW_TIME: 
            cmd_switch_time(fd_reply,fd_request,pathtasks); 
          break;
          case CLIENT_REQUEST_EXEC_TASK:
            time2 = time(NULL);
            to_execute(fd_reply,fd_request,pathtasks,pid,time2);
          break;
          case CLIENT_REQUEST_REMOVE_TASK:
            cmd_remove_task(fd_request,fd_reply ,pathtasks,taskid);
          break;
          case CLIENT_REQUEST_CREATE_TASK: 
            cmd_create (fd_request,fd_reply,buftaskmax,pathtasks);
          break;
          case CLIENT_REQUEST_SET_CMD:
            cmd_set_cmd_task(fd_request,fd_reply,pathtasks);
          break;  
          case CLIENT_REQUEST_TERMINATE:  
            kill(pid,SIGTERM);
            out=1;  
          break;
          case CLIENT_REQUEST_GET_STDOUT: 
            get_std(fd_request ,fd_reply, 1,pathtasks);
          break;
          case CLIENT_REQUEST_GET_STDERR: 
            get_std(fd_request ,fd_reply, 0,pathtasks);
          break;
          case CLIENT_REQUEST_GET_TIMES_AND_EXITCODES:
            cmd_time_exit_code(fd_request,fd_reply,taskid,pathtasks); 
          break; 
          case CLIENT_REQUEST_LIST_TASKS:
            cmd_list(fd_reply,pathtasks);  
          break;
          case CLIENT_REQUEST_RESET_TASKMAX:
            reset_taskmax(fd_reply,buftaskmax,pathtasks);
          break; 
        }
		  } 
    } 
	
    wait(NULL);//ce wait pour le terminate
    uint16_t ok= SERVER_REPLY_OK;
    write(fd_reply,&ok,sizeof(uint16_t));
    close(fd_request);
    close(fd_reply);
    
  }//FIN GRAND PERE
  else
  {//DEBUT "PERE"
 
    time_t time2 = time(NULL);
    uint16_t code;
    struct sigaction s;
    s.sa_handler = handler; 
    
    while(1){
      pid_t pid2=fork();
      if(pid2>0){//PERE
        sigaction(SIGALRM,&s, NULL);
        sigaction(SIGTERM,&s, NULL);
        alarm(60);
        pause(); 
        waitpid(pid2,NULL,WNOHANG);
        time2=time(NULL);
      }//FIN PERE
      else
      {//PETIT FILS 
        executioner_pulse(pid2,time2);//pid2 == 0
      }//FIN PETIT FILS
    }
    while (wait(NULL) > 0);
    free(pathtasks_saturnd);
    exit(EXIT_SUCCESS);
  }
}
