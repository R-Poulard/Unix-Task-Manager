
int get_std(int fd_request ,int fd_reply, int type, char *pathtasks);
