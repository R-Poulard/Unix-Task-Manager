# SY5-projet-2021-2022

Le projet du cours de systèmes d'exploitation (L3), 2021-2022

Ce dépôt contient :

  - l'[énoncé](enonce.md) du projet, complété de détails sur le
    [protocole](protocole.md) de communication entre le démon et son
    client,

  - un [script de test](run-cassini-tests.sh) du client (`cassini`), et
    le jeu de [tests](tests) correspondant, 

  - quelques fichiers sources pour vous aider à démarrer.

Par ailleurs, nous avons ouvert un [serveur
discord](https://discord.gg/7ArJtu8Xnv) avec un salon dédié aux questions concernant le projet.

