int get_std(int fd_request ,int fd_reply, int type, char *pathtasks){
	uint64_t id;
	char * buf;
	read(fd_request,&id, sizeof(uint64_t));//READ
	id = htobe64(id);
	char * pathtasks_file=malloc(PATH_SIZE);//MALLOC
  strcpy(pathtasks_file,pathtasks);
	snprintf(pathtasks_file + strlen(pathtasks), 100-strlen(pathtasks),"%"PRIu64,id );

	DIR * dir = opendir(pathtasks_file);
	if(dir==NULL){
	  buf=malloc(2*sizeof(uint16_t));//MALLOC
    uint16_t uerror= htobe16(SERVER_REPLY_ERROR);
    uint16_t uerror_type=htobe16(SERVER_REPLY_ERROR_NOT_FOUND);
    memcpy(buf,&uerror,sizeof(uint16_t));
    memcpy(buf+sizeof(uint16_t),&uerror_type,sizeof(uint16_t));
    write(fd_reply,buf,2*sizeof(uint16_t));//WRITE
    free(buf);
	}
  else
  {
		char * pathtasks_std;
		if(type){
			pathtasks_std = path_constr(pathtasks_std,pathtasks_file,CMD_STDOUT);
		} else {
			pathtasks_std = path_constr(pathtasks_std,pathtasks_file,CMD_STDERR);
		}

		int fd_std = open(pathtasks_std, O_RDONLY);//OPEN
		if(fd_std== -1){
			buf=malloc(2*sizeof(uint16_t));//MALLOC
			uint16_t uerror= htobe16(SERVER_REPLY_ERROR);
			uint16_t uerror_type= htobe16(SERVER_REPLY_ERROR_NEVER_RUN);
			memcpy(buf,&uerror,sizeof(uint16_t));
			memcpy(buf+sizeof(uint16_t),&uerror_type,sizeof(uint16_t));
			write(fd_reply,buf,2*sizeof(uint16_t));//WRITE
			free(buf);
		} else {
			int size_buf = BUFFER_BLOCK;

			char *buffer = malloc(size_buf);//MALLOC
			int taille_buff = size_buf;
			uint32_t taille = 0;
			int rd;

			while((rd = read(fd_std, buffer+taille, size_buf))> 0){
				taille = taille+rd;
				if(rd == size_buf){
				  buffer = realloc(buffer, taille_buff + size_buf);
				  taille_buff = taille_buff + size_buf;
				}
			}//READ
			//if(rd==-1)go to
			uint16_t ok = htobe16(SERVER_REPLY_OK);
			uint32_t hto_taille = htobe32(taille);

			char *buff_total = malloc(sizeof(uint16_t)+ sizeof(uint32_t)+taille);//MALLOC
			memcpy(buff_total,&ok, sizeof(uint16_t));
			memcpy(buff_total+sizeof(uint16_t), &hto_taille , sizeof(uint32_t));
			strncpy(buff_total+sizeof(uint16_t)+sizeof(uint32_t), buffer, taille);
			write_in_block(fd_reply,buff_total,sizeof(uint16_t)+ sizeof(uint32_t)+taille);//WRITE


      free(buffer);
		  close(fd_std);
    }
    free(pathtasks_std);
	}
  free(pathtasks_file);
}
