#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "../include/timing.h"
#include "../include/timing-text-io.h"
#include <endian.h>
#include <time.h>
#include <dirent.h>
#include <errno.h>
#include <sys/wait.h>
#include "../include/server-reply.h"
#include <assert.h>
#include <inttypes.h>

int cpy(char * buf1,char *buf2,size_t size){
  strncpy(buf2,buf1,size);
  buf2[size]='\0';
  return 1;
}
int main(int argc, char * argv[]){
  //COMMAND
  int fd_request=open("cmd",O_RDWR | O_CREAT,0666);
  char * buffer=malloc(1024);
  unsigned int memindex=0;
  uint32_t conv32 = htobe32(argc-1);
    
    memcpy(buffer+memindex,&conv32,sizeof(uint32_t));//copy number of arguments (of command)
    memindex+=sizeof(uint32_t);
    
    for(int j=0;j<argc-1;j++){
    
	uint32_t taille = strlen(argv[j+1]);//taille de argv[pos]
	conv32 = htobe32(taille);//htobe32
	memcpy(buffer+memindex,&conv32,sizeof(uint32_t));//copy size of argument at index
	memindex+=sizeof(uint32_t);
	memcpy(buffer+memindex,argv[j+1],taille);//copy argument at index
	printf("A écrit at j=%d size=%d s=%s\n",j,strlen(argv[j+1]),argv[j+1]);
	memindex+=taille;
    }
    if(write(fd_request,buffer,memindex)<0){//WRITE BUFFER
      printf("Erreur d'ecrit\n");
      exit(2);
    }//FIN COMMAND
    
    printf("Debut lecture command\n");
    lseek( fd_request,  0,  SEEK_SET);//Tête de lecture au début du fichier pour lire cmd_argc
              uint32_t cmd_argc;
              uint32_t * buf32;
              char ** cmd_argv;
              printf("Avant read fd_cmd\n");
              
              int rd=read(fd_request,&cmd_argc,sizeof(uint32_t));//READ
              perror("read");
               printf("argc av htobe :%d\n", cmd_argc);
              cmd_argc=htobe32(cmd_argc);

              char ** tab;//=malloc(sizeof(char *) * cmd_argc);//MALLOC
              int tmp = sizeof(char *) * cmd_argc;
              tab = malloc(tmp);
              assert(tab!=NULL);
             /* printf("CALC : %d\n",tmp);
              printf("taille char* :%d\n", sizeof(char*));
              printf("taille totale* :%d\n", sizeof(tab));
              printf("argc apr htobe :%d\n", cmd_argc);
              printf("apres tab\n");
            */  
              for(int i=0;i<cmd_argc;i++){
                printf("i=%d\n",i);
               
                uint32_t taille_str;
                rd=read(fd_request,&taille_str,sizeof(uint32_t));//READ L
                taille_str = htobe32(taille_str);
                printf("at i taille=%d\n",taille_str);
               // printf("at i rd=%d\n",rd);
               
                char * str=malloc(taille_str);
                rd=read(fd_request,str,sizeof(char)*taille_str);//READ char *
                printf("J'ai lu %s de taille %d!\n",str,taille_str);
                //printf("at i rd=%d\n",rd);
                char * str_final=malloc(taille_str+1);
                cpy(str,str_final,taille_str);
                tab[i]=malloc(sizeof(char*)*taille_str+1);
                strncpy(tab[i],str_final,taille_str+1);
                printf("tab[%d]=%s\n",i,tab[i]);
              }
              
              
              //tab contient tout les argv
              
               int fd_out=open("stdout",O_CREAT|O_WRONLY | O_TRUNC, 0666);//OPEN
              int fd_err=open("stderr",O_CREAT|O_WRONLY | O_TRUNC,0666);//OPEN
              dup2(fd_out,STDOUT_FILENO);//DUP
              dup2(fd_err,STDERR_FILENO);//DUP
              
              execvp(tab[0],tab);//EXEC
              
}






